import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.net.*;
import java.util.Enumeration;

// The game screen. The same window is used by both players:
//   host   -> runs the GameEngine and sends the state to the client
//   client -> sends its key presses to the host and draws the state it receives
public class GameWindow extends JFrame implements Connection.Listener {

    private final MenuFrame menu;
    private final boolean isHost;
    private final String myName;

    private GameEngine engine;            // host only
    private ServerSocket serverSocket;    // host only
    private javax.swing.Timer gameTimer;  // host only
    private Connection connection;

    private final GamePanel panel = new GamePanel();
    private final JLabel p1Label = new JLabel();
    private final JLabel p2Label = new JLabel();
    private final JLabel timeLabel = new JLabel("Time: 60");
    private final JLabel statusLabel = new JLabel(" ");
    private final JButton restartButton = new JButton("Restart");

    private String lastStatus = "";
    private boolean closed = false;

    // ---------- host constructor ----------
    public GameWindow(MenuFrame menu, String name, ServerSocket server) {
        this.menu = menu;
        this.isHost = true;
        this.myName = name;
        this.serverSocket = server;

        engine = new GameEngine();
        engine.setNames(name, "Player 2");
        engine.setMessage("Waiting for opponent...");

        buildWindow();
        showState(engine.getState());
        statusLabel.setText("Waiting... tell your friend to join with IP: " + findLocalIps()
                + "  Port: " + server.getLocalPort());

        // this timer is the heartbeat of the game, it starts when the second player joins
        gameTimer = new javax.swing.Timer(GameEngine.TICK_MS, e -> hostTick());
        waitForOpponent();
    }

    // ---------- client constructor ----------
    public GameWindow(MenuFrame menu, String name, Socket socket) {
        this.menu = menu;
        this.isHost = false;
        this.myName = name;

        buildWindow();
        statusLabel.setText("Connected to host. Get ready!");
        try {
            connection = new Connection(socket, this);
            connection.start();
            connection.send("HELLO " + name);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Could not set up the connection: " + e.getMessage());
            closeWindow();
        }
    }

    // ---------- building the screen ----------
    private void buildWindow() {
        setTitle("NeonSnake LAN - " + (isHost ? "Host" : "Client") + " (" + myName + ")");
        setIconImage(AppIcon.create(64));
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        setLayout(new BorderLayout());

        // top bar: scores and timer
        JPanel top = new JPanel(new GridLayout(1, 3));
        top.setBackground(new Color(30, 41, 59));
        for (JLabel l : new JLabel[]{p1Label, timeLabel, p2Label}) {
            l.setForeground(Color.WHITE);
            l.setFont(new Font("SansSerif", Font.BOLD, 16));
            l.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
            top.add(l);
        }
        timeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        p2Label.setHorizontalAlignment(SwingConstants.RIGHT);
        add(top, BorderLayout.NORTH);

        add(panel, BorderLayout.CENTER);

        // bottom bar: status text and restart button
        JPanel bottom = new JPanel(new BorderLayout());
        bottom.setBackground(new Color(30, 41, 59));
        statusLabel.setForeground(new Color(203, 213, 225));
        statusLabel.setBorder(BorderFactory.createEmptyBorder(6, 12, 6, 12));
        restartButton.setFocusable(false);   // so the arrow keys keep working after a click
        restartButton.setEnabled(false);
        restartButton.addActionListener(e -> onRestartClicked());
        bottom.add(statusLabel, BorderLayout.CENTER);
        bottom.add(restartButton, BorderLayout.EAST);
        add(bottom, BorderLayout.SOUTH);

        panel.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                handleKey(e.getKeyCode());
            }
        });

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                closeWindow();
            }
        });

        pack();
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
        panel.requestFocusInWindow();
    }

    // ---------- host side ----------
    // accept() blocks until someone connects, so it runs in its own thread
    private void waitForOpponent() {
        Thread t = new Thread(() -> {
            try {
                Socket s = serverSocket.accept();
                serverSocket.close();   // only 2 players, no need to accept more
                SwingUtilities.invokeLater(() -> opponentJoined(s));
            } catch (IOException e) {
                // happens when the host closes the window while still waiting
            }
        });
        t.setDaemon(true);
        t.start();
    }

    private void opponentJoined(Socket s) {
        try {
            connection = new Connection(s, this);
            connection.start();
            statusLabel.setText("Opponent connected!");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Could not set up the connection: " + e.getMessage());
        }
    }

    private void hostTick() {
        engine.tick();
        GameState gs = engine.getState();
        showState(gs);
        if (connection != null) {
            connection.send("STATE " + gs.toText());
        }
    }

    // ---------- messages from the other computer (already moved onto the Swing thread) ----------
    private void handleMessage(String line) {
        if (isHost) {
            if (line.startsWith("HELLO ") && !gameTimer.isRunning()) {
                engine.setNames(myName, line.substring(6));
                engine.start();
                gameTimer.start();
            } else if (line.startsWith("DIR ")) {
                try {
                    engine.turn(2, Integer.parseInt(line.substring(4).trim()));
                } catch (NumberFormatException e) {
                    // bad message, just ignore it
                }
            } else if (line.equals("RESTART") && engine.isOver()) {
                engine.start();
            }
        } else if (line.startsWith("STATE ")) {
            try {
                showState(GameState.fromText(line.substring(6)));
            } catch (RuntimeException e) {
                // broken line, skip it. The next one comes in 120 ms anyway
            }
        }
    }

    @Override
    public void onMessage(String line) {
        SwingUtilities.invokeLater(() -> handleMessage(line));
    }

    @Override
    public void onDisconnect() {
        SwingUtilities.invokeLater(() -> {
            if (closed) {
                return;
            }
            connection = null;
            if (isHost) {
                engine.abort("Opponent disconnected");
                showState(engine.getState());
                JOptionPane.showMessageDialog(this, "Your opponent left the game.");
            } else {
                JOptionPane.showMessageDialog(this, "Lost connection to the host.");
                closeWindow();
            }
        });
    }

    // ---------- input ----------
    private void handleKey(int code) {
        int dir;
        switch (code) {
            case KeyEvent.VK_UP:    case KeyEvent.VK_W: dir = Snake.UP;    break;
            case KeyEvent.VK_DOWN:  case KeyEvent.VK_S: dir = Snake.DOWN;  break;
            case KeyEvent.VK_LEFT:  case KeyEvent.VK_A: dir = Snake.LEFT;  break;
            case KeyEvent.VK_RIGHT: case KeyEvent.VK_D: dir = Snake.RIGHT; break;
            default: return;
        }
        if (isHost) {
            engine.turn(1, dir);
        } else if (connection != null) {
            connection.send("DIR " + dir);
        }
    }

    private void onRestartClicked() {
        if (isHost) {
            engine.start();
        } else if (connection != null) {
            connection.send("RESTART");
        }
    }

    // ---------- updating the screen ----------
    private void showState(GameState gs) {
        panel.setState(gs);
        p1Label.setText(gs.name1 + (isHost ? " (You)" : "") + ": " + gs.score1);
        p2Label.setText(gs.name2 + (isHost ? "" : " (You)") + ": " + gs.score2);
        timeLabel.setText("Time: " + gs.timeLeft);
        restartButton.setEnabled(gs.status.equals("OVER") && connection != null);

        // runs once, at the moment the game finishes
        if (gs.status.equals("OVER") && !lastStatus.equals("OVER")) {
            int myScore = isHost ? gs.score1 : gs.score2;
            boolean record = HighScore.submit(myScore);
            statusLabel.setText("Game over. Your score: " + myScore
                    + "  |  Best on this PC: " + HighScore.load() + (record ? "  (new record!)" : ""));
        } else if (gs.status.equals("RUNNING") && !lastStatus.equals("RUNNING")) {
            statusLabel.setText("Arrow keys / WASD to move. Eat the red food!");
        }
        lastStatus = gs.status;
    }

    // ---------- cleanup ----------
    private void closeWindow() {
        if (closed) {
            return;
        }
        closed = true;
        if (gameTimer != null) {
            gameTimer.stop();
        }
        try {
            if (serverSocket != null) {
                serverSocket.close();
            }
        } catch (IOException e) {
            // ignore
        }
        if (connection != null) {
            connection.close();
        }
        dispose();
        menu.setVisible(true);
    }

    // The host needs to tell the friend an IP address. A PC can have many network adapters
    // (wifi, virtual ones...) so we list every normal IPv4 address we can find.
    private String findLocalIps() {
        StringBuilder sb = new StringBuilder();
        try {
            Enumeration<NetworkInterface> nets = NetworkInterface.getNetworkInterfaces();
            while (nets.hasMoreElements()) {
                NetworkInterface ni = nets.nextElement();
                if (!ni.isUp() || ni.isLoopback()) {
                    continue;
                }
                Enumeration<InetAddress> addrs = ni.getInetAddresses();
                while (addrs.hasMoreElements()) {
                    InetAddress a = addrs.nextElement();
                    if (a instanceof Inet4Address && a.isSiteLocalAddress()) {
                        if (sb.length() > 0) sb.append(" / ");
                        sb.append(a.getHostAddress());
                    }
                }
            }
        } catch (SocketException e) {
            return "unknown (check ipconfig)";
        }
        return sb.length() == 0 ? "unknown (check ipconfig)" : sb.toString();
    }
}
